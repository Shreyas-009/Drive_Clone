// const api = "https://driveclone-production.up.railway.app/api/";
const api = "http://localhost:8080/api/";
// https://drive-clone-five.vercel.app/api/
export default api;
